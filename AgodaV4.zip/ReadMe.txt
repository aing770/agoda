1. Paste email di file "email.txt"
2. Buka file "config.php", dan set password, firstname, lastname.
3. Run "php agoda.php"

NB: utamakan email original, jangan fake mail, atau dottrick.