<?php
$password = 'YOUR-PASSWORD';
$firstName = 'YOUR-FIRSTNAME';
$lastName = 'YOUR-LAST-NAME';